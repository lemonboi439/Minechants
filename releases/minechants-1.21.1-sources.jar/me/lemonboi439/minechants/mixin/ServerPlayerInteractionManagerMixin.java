package me.lemonboi439.minechants.mixin;

import me.lemonboi439.minechants.Minechants;
import me.lemonboi439.minechants.enchantment.ModEnchantments;
import me.lemonboi439.minechants.util.FeatureToggleState;
import me.lemonboi439.minechants.util.MiningContext;
import me.lemonboi439.minechants.util.ToggleFeature;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3481;
import net.minecraft.class_5362;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class ServerPlayerInteractionManagerMixin {
    @Unique
    private static final class_6862<net.minecraft.class_2248> MINECHANTS_THREE_BY_THREE_BLACKLIST = class_6862.method_40092(
            class_7924.field_41254,
            class_2960.method_60655(Minechants.MOD_ID, "3x3_miner_blacklist")
    );

    @Unique
    private static final double[] minechants$explosiveRadii = {1.35D, 1.85D, 2.35D};
    @Unique
    private static final class_5362 minechants$visualExplosionBehavior = new class_5362() {
        @Override
        public boolean method_29554(class_1927 explosion, net.minecraft.class_1922 world, class_2338 pos, class_2680 state, float power) {
            return false;
        }
    };

    @Shadow @Final protected class_3222 player;

    @Unique
    private boolean minechants$processingExplosiveBreak;
    @Unique
    private boolean minechants$processingMinerBreak;

    @Inject(method = "tryBreakBlock", at = @At("HEAD"))
    private void minechants$pushMiningContext(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        MiningContext.push(this.player, this.player.method_6047());
    }

    @Inject(method = "tryBreakBlock", at = @At("RETURN"))
    private void minechants$clearMiningContext(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        MiningContext.clear();
    }

    @Inject(method = "tryBreakBlock", at = @At("RETURN"))
    private void minechants$breakExplosiveBurst(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() || this.minechants$processingExplosiveBreak) {
            return;
        }

        class_1799 tool = this.player.method_6047();
        if (tool.method_7960()) {
            return;
        }

        var enchantmentLookup = this.player.method_5770().method_30349().method_30530(class_7924.field_41265);
        var explosiveEntry = enchantmentLookup.method_40264(ModEnchantments.EXPLOSIVE).orElseThrow();
        int level = class_1890.method_8225(explosiveEntry, tool);
        if (level <= 0 || !FeatureToggleState.isEnabled(this.player, ToggleFeature.EXPLOSIVE)) {
            this.minechants$scheduleMinerBurst(pos, tool);
            return;
        }

        class_2338 direction = this.minechants$getForwardStep(this.player.method_5828(1.0F));
        if (direction.equals(class_2338.field_10980)) {
            return;
        }

        this.minechants$processingExplosiveBreak = true;
        try {
            class_3225 manager = (class_3225) (Object) this;
            double radius = minechants$explosiveRadii[Math.min(level, minechants$explosiveRadii.length) - 1];
            class_243 center = class_243.method_24953(pos).method_1019(class_243.method_24954(direction).method_1021(0.8D + (0.35D * level)));
            this.player.method_5770().method_55117(
                    this.player,
                    this.player.method_5770().method_48963().method_48819(this.player, this.player),
                    minechants$visualExplosionBehavior,
                    center.field_1352,
                    center.field_1351,
                    center.field_1350,
                    1.0F + (level * 0.35F),
                    false,
                    class_1937.class_7867.field_40891
            );
            this.minechants$breakBlastArea(manager, center, radius, pos);
        } finally {
            this.minechants$processingExplosiveBreak = false;
        }
    }

    @Unique
    private void minechants$scheduleMinerBurst(class_2338 pos, class_1799 tool) {
        if (this.minechants$processingMinerBreak) {
            return;
        }

        var enchantmentLookup = this.player.method_5770().method_30349().method_30530(class_7924.field_41265);
        var minerEntry = enchantmentLookup.method_40264(ModEnchantments.THREE_BY_THREE_MINER).orElseThrow();
        if (class_1890.method_8225(minerEntry, tool) <= 0 || !FeatureToggleState.isEnabled(this.player, ToggleFeature.THREE_BY_THREE_MINER)) {
            return;
        }

        class_2338 forward = this.minechants$getForwardStep(this.player.method_5828(1.0F));
        if (forward.equals(class_2338.field_10980)) {
            return;
        }

        this.minechants$processingMinerBreak = true;
        try {
            class_3225 manager = (class_3225) (Object) this;
            for (class_2338 offset : this.minechants$getMinerOffsets(forward)) {
                class_2338 target = pos.method_10081(offset);
                if (this.minechants$canThreeByThreeMine(target)) {
                    manager.method_14266(target);
                }
            }
        } finally {
            this.minechants$processingMinerBreak = false;
        }
    }

    @Unique
    private class_2338 minechants$getForwardStep(class_243 rotation) {
        double x = Math.abs(rotation.field_1352);
        double y = Math.abs(rotation.field_1351);
        double z = Math.abs(rotation.field_1350);

        if (x >= y && x >= z) {
            return class_2338.method_49637(Math.signum(rotation.field_1352), 0, 0);
        }

        if (z >= x && z >= y) {
            return class_2338.method_49637(0, 0, Math.signum(rotation.field_1350));
        }

        return class_2338.method_49637(0, Math.signum(rotation.field_1351), 0);
    }

    @Unique
    private void minechants$breakBlastArea(class_3225 manager, class_243 center, double radius, class_2338 origin) {
        int blockRadius = (int) Math.ceil(radius);
        class_2338 centerPos = class_2338.method_49638(center);
        for (class_2338 target : class_2338.method_10097(centerPos.method_10069(-blockRadius, -blockRadius, -blockRadius), centerPos.method_10069(blockRadius, blockRadius, blockRadius))) {
            if (target.equals(origin)) {
                continue;
            }

            if (class_243.method_24953(target).method_1025(center) > radius * radius) {
                continue;
            }

            manager.method_14266(target.method_10062());
        }
    }

    @Unique
    private class_2338[] minechants$getMinerOffsets(class_2338 forward) {
        List<class_2338> offsets = new ArrayList<>(8);
        class_2338 axisA = this.minechants$getPrimaryPerpendicularAxis(forward);
        class_2338 axisB = this.minechants$getSecondaryPerpendicularAxis(forward);

        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                if (a == 0 && b == 0) {
                    continue;
                }

                offsets.add(axisA.method_35830(a).method_10081(axisB.method_35830(b)));
            }
        }

        offsets.sort(
                Comparator
                        .comparingInt((class_2338 offset) -> this.minechants$getMinerSquaredDistance(offset, forward, axisA, axisB))
                        .thenComparingInt(offset -> this.minechants$getForwardDepth(offset, forward))
                        .thenComparingInt(offset -> this.minechants$getPlaneManhattan(offset, axisA, axisB))
        );

        return offsets.toArray(class_2338[]::new);
    }

    @Unique
    private class_2338 minechants$getPrimaryPerpendicularAxis(class_2338 forward) {
        if (forward.method_10263() != 0) {
            return new class_2338(0, 1, 0);
        }

        if (forward.method_10264() != 0) {
            return new class_2338(1, 0, 0);
        }

        return new class_2338(0, 1, 0);
    }

    @Unique
    private class_2338 minechants$getSecondaryPerpendicularAxis(class_2338 forward) {
        if (forward.method_10263() != 0) {
            return new class_2338(0, 0, 1);
        }

        if (forward.method_10264() != 0) {
            return new class_2338(0, 0, 1);
        }

        return new class_2338(1, 0, 0);
    }

    @Unique
    private int minechants$getMinerSquaredDistance(class_2338 offset, class_2338 forward, class_2338 axisA, class_2338 axisB) {
        int depth = this.minechants$getForwardDepth(offset, forward);
        int a = this.minechants$getAxisComponent(offset, axisA);
        int b = this.minechants$getAxisComponent(offset, axisB);
        return (depth * depth) + (a * a) + (b * b);
    }

    @Unique
    private int minechants$getForwardDepth(class_2338 offset, class_2338 forward) {
        return Math.abs(this.minechants$getAxisComponent(offset, forward));
    }

    @Unique
    private int minechants$getPlaneManhattan(class_2338 offset, class_2338 axisA, class_2338 axisB) {
        return Math.abs(this.minechants$getAxisComponent(offset, axisA))
                + Math.abs(this.minechants$getAxisComponent(offset, axisB));
    }

    @Unique
    private int minechants$getAxisComponent(class_2338 offset, class_2338 axis) {
        return (offset.method_10263() * axis.method_10263()) + (offset.method_10264() * axis.method_10264()) + (offset.method_10260() * axis.method_10260());
    }

    @Unique
    private boolean minechants$canThreeByThreeMine(class_2338 pos) {
        class_2680 state = this.player.method_5770().method_8320(pos);
        if (state.method_26215() || state.method_31709()) {
            return false;
        }

        if (state.method_26164(MINECHANTS_THREE_BY_THREE_BLACKLIST)) {
            return false;
        }

        if (!state.method_26164(class_3481.field_33715)) {
            return false;
        }

        return true;
    }
}
