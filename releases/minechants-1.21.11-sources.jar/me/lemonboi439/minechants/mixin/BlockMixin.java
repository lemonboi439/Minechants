package me.lemonboi439.minechants.mixin;

import me.lemonboi439.minechants.config.MinechantsConfig;
import me.lemonboi439.minechants.enchantment.ModEnchantments;
import me.lemonboi439.minechants.util.FeatureToggleState;
import me.lemonboi439.minechants.util.MiningContext;
import me.lemonboi439.minechants.util.ToggleFeature;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3861;
import net.minecraft.class_3956;
import net.minecraft.class_7924;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

@Mixin(class_2248.class)
public abstract class BlockMixin {
    private static final double MINECHANTS_MAGNETIC_SPEED_MULTIPLIER = 1.3D;

    @Inject(method = "getDroppedStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Ljava/util/List;", at = @At("HEAD"), cancellable = true)
    private static void getDroppedStacks(class_2680 state, class_3218 world, class_2338 pos, class_2586 blockEntity, class_1297 entity, class_1799 tool, CallbackInfoReturnable<List<class_1799>> cir) {
        if (!(entity instanceof net.minecraft.class_3222 player)
                || !MinechantsConfig.smeltingEnabled
                || !FeatureToggleState.isEnabled(player, ToggleFeature.SMELTING)) {
            return;
        }

        var enchantmentLookup = world.method_30349().method_30530(class_7924.field_41265);
        var smeltingEntry = enchantmentLookup.method_46747(ModEnchantments.SMELTING);
        if (class_1890.method_8225(smeltingEntry, tool) > 0) {
            var silkTouchEntry = enchantmentLookup.method_46747(class_1893.field_9099);
            if (class_1890.method_8225(silkTouchEntry, tool) > 0) {
                return;
            }

            var input = new class_9696(new class_1799(state.method_26204().method_8389()));
            Optional<class_8786<class_3861>> recipe = world.method_64577()
                    .method_8132(class_3956.field_17546, input, world);

            if (recipe.isPresent()) {
                class_1799 result = recipe.get().comp_1933().method_59998(input, world.method_30349());
                if (!result.method_7960()) {
                    cir.setReturnValue(Collections.singletonList(result));
                }
            }
        }
    }

    @Inject(method = "dropStack(Lnet/minecraft/world/World;Ljava/util/function/Supplier;Lnet/minecraft/item/ItemStack;)V", at = @At("HEAD"), cancellable = true)
    private static void minechants$pullDropsMagnetically(net.minecraft.class_1937 world, Supplier<class_1542> itemEntitySupplier, class_1799 stack, CallbackInfo ci) {
        if (!(world instanceof class_3218 serverWorld) || stack.method_7960()) {
            return;
        }

        MiningContext.Context context = MiningContext.getCurrent();
        if (context == null || context.player() == null || context.tool().method_7960()) {
            return;
        }

        if (context.player().method_51469() != serverWorld
                || !MinechantsConfig.magneticEnabled
                || !FeatureToggleState.isEnabled(context.player(), ToggleFeature.MAGNETIC)) {
            return;
        }

        var enchantmentLookup = serverWorld.method_30349().method_30530(class_7924.field_41265);
        var magneticEntry = enchantmentLookup.method_46747(ModEnchantments.MAGNETIC);
        if (class_1890.method_8225(magneticEntry, context.tool()) <= 0) {
            return;
        }

        class_1542 itemEntity = itemEntitySupplier.get();
        if (itemEntity == null) {
            return;
        }

        class_243 playerCenter = new class_243(context.player().method_23317(), context.player().method_23318() + 0.75D, context.player().method_23321());
        class_243 delta = playerCenter.method_1023(itemEntity.method_23317(), itemEntity.method_23318(), itemEntity.method_23321());
        if (delta.method_1027() > 1.0E-6D) {
            class_243 velocity = delta.method_1029().method_1021(
                    Math.min(0.65D, 0.22D + (delta.method_1033() * 0.05D)) * MINECHANTS_MAGNETIC_SPEED_MULTIPLIER
            );
            itemEntity.method_18799(velocity);
        }

        ci.cancel();
        world.method_8649(itemEntity);
    }
}
