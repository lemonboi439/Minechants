package me.lemonboi439.minechants.client;

import me.lemonboi439.minechants.config.MinechantsConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public final class MinechantsConfigScreen {
    private MinechantsConfigScreen() {
    }

    public static class_437 create(class_437 parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_43471("config.minechants.title"));
        ConfigCategory mining = builder.getOrCreateCategory(class_2561.method_43470("Mining"));
        ConfigEntryBuilder entries = builder.entryBuilder();

        mining.addEntry(entries.startBooleanToggle(class_2561.method_43471("config.minechants.three_by_three_enabled"), MinechantsConfig.threeByThreeEnabled)
                .setDefaultValue(true)
                .setSaveConsumer(value -> MinechantsConfig.threeByThreeEnabled = value)
                .build());
        mining.addEntry(entries.startBooleanToggle(class_2561.method_43471("config.minechants.explosive_enabled"), MinechantsConfig.explosiveEnabled)
                .setDefaultValue(true)
                .setSaveConsumer(value -> MinechantsConfig.explosiveEnabled = value)
                .build());
        mining.addEntry(entries.startBooleanToggle(class_2561.method_43471("config.minechants.smelting_enabled"), MinechantsConfig.smeltingEnabled)
                .setDefaultValue(true)
                .setSaveConsumer(value -> MinechantsConfig.smeltingEnabled = value)
                .build());
        mining.addEntry(entries.startBooleanToggle(class_2561.method_43471("config.minechants.magnetic_enabled"), MinechantsConfig.magneticEnabled)
                .setDefaultValue(true)
                .setSaveConsumer(value -> MinechantsConfig.magneticEnabled = value)
                .build());
        mining.addEntry(entries.startIntSlider(class_2561.method_43471("config.minechants.explosive_power"), MinechantsConfig.explosivePower, 1, 5)
                .setDefaultValue(2)
                .setSaveConsumer(value -> MinechantsConfig.explosivePower = value)
                .build());

        builder.setSavingRunnable(MinechantsConfig::save);
        return builder.build();
    }
}
