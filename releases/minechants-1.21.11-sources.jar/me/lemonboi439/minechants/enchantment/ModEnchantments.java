package me.lemonboi439.minechants.enchantment;

import me.lemonboi439.minechants.Minechants;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModEnchantments {
    public static final class_5321<class_1887> SMELTING = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(Minechants.MOD_ID, "smelting")
    );
    public static final class_5321<class_1887> EXPLOSIVE = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(Minechants.MOD_ID, "explosive")
    );
    public static final class_5321<class_1887> THREE_BY_THREE_MINER = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(Minechants.MOD_ID, "three_by_three_miner")
    );
    public static final class_5321<class_1887> MAGNETIC = class_5321.method_29179(
            class_7924.field_41265,
            class_2960.method_60655(Minechants.MOD_ID, "magnetic")
    );

    public static void registerModEnchantments() {
        System.out.println("Registering mod enchantments for " + Minechants.MOD_ID);
    }
}
