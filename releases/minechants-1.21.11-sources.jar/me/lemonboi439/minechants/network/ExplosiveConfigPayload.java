package me.lemonboi439.minechants.network;

import me.lemonboi439.minechants.Minechants;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ExplosiveConfigPayload(boolean disableExplosiveOnServer) implements class_8710 {
    public static final class_8710.class_9154<ExplosiveConfigPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Minechants.MOD_ID, "explosive_config"));
    public static final class_9139<class_9129, ExplosiveConfigPayload> CODEC = class_9139.method_56434(
            class_9135.field_48547,
            ExplosiveConfigPayload::disableExplosiveOnServer,
            ExplosiveConfigPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
