package me.lemonboi439.minechants.util;

import net.minecraft.class_1799;
import net.minecraft.class_3222;

public final class MiningContext {
    private static final ThreadLocal<Context> CURRENT = new ThreadLocal<>();

    private MiningContext() {
    }

    public static void push(class_3222 player, class_1799 tool) {
        CURRENT.set(new Context(player, tool));
    }

    public static void clear() {
        CURRENT.remove();
    }

    public static Context getCurrent() {
        return CURRENT.get();
    }

    public record Context(class_3222 player, class_1799 tool) {
    }
}
