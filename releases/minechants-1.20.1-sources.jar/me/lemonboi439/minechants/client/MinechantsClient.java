package me.lemonboi439.minechants.client;

import me.lemonboi439.minechants.Minechants;
import me.lemonboi439.minechants.util.ToggleFeature;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class MinechantsClient implements ClientModInitializer {
    private static final String MINECHANTS_CATEGORY = "key.categories.minechants";
    private static final class_304 TOGGLE_SMELTING_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minechants.toggle_smelting",
            GLFW.GLFW_KEY_J,
            MINECHANTS_CATEGORY
    ));
    private static final class_304 TOGGLE_MINER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minechants.toggle_miner",
            GLFW.GLFW_KEY_G,
            MINECHANTS_CATEGORY
    ));
    private static final class_304 TOGGLE_EXPLOSIVE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minechants.toggle_explosive",
            GLFW.GLFW_KEY_H,
            MINECHANTS_CATEGORY
    ));
    private static final class_304 TOGGLE_MAGNETIC_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minechants.toggle_magnetic",
            GLFW.GLFW_KEY_K,
            MINECHANTS_CATEGORY
    ));

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            this.minechants$handleToggle(client, TOGGLE_SMELTING_KEY, ToggleFeature.SMELTING);
            this.minechants$handleToggle(client, TOGGLE_MINER_KEY, ToggleFeature.THREE_BY_THREE_MINER);
            this.minechants$handleToggle(client, TOGGLE_EXPLOSIVE_KEY, ToggleFeature.EXPLOSIVE);
            this.minechants$handleToggle(client, TOGGLE_MAGNETIC_KEY, ToggleFeature.MAGNETIC);
        });
    }

    private void minechants$handleToggle(net.minecraft.class_310 client, class_304 keyBinding, ToggleFeature feature) {
        while (keyBinding.method_1436()) {
            if (client.field_1724 != null && ClientPlayNetworking.canSend(Minechants.TOGGLE_FEATURE_ID)) {
                class_2540 buf = PacketByteBufs.create();
                buf.writeInt(feature.ordinal());
                ClientPlayNetworking.send(Minechants.TOGGLE_FEATURE_ID, buf);
            }
        }
    }
}
