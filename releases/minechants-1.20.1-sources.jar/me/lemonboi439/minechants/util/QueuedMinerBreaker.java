package me.lemonboi439.minechants.util;

import net.minecraft.class_2338;

public interface QueuedMinerBreaker {
    void minechants$runQueuedMinerBreak(class_2338 pos);
}
